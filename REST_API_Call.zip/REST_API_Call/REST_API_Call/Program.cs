﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace REST_API_Call
{
    class Program
    {
        private static readonly HttpClient Client = new HttpClient();

        static async Task Main(string[] args)
        {
            // Make a GET request
            string getResponse = await GetRequestAsync("https://jsonplaceholder.typicode.com/todos/101");
            Console.WriteLine("GET response:");
            Console.WriteLine(getResponse);

            // Make a POST request
            string postResponse = await PostRequestAsync("https://jsonplaceholder.typicode.com/posts", "{\"title\": \"John\", \"body\": 30, \"userId\": 69}");
            Console.WriteLine("POST response:");
            Console.WriteLine(postResponse);
        }

        static async Task<string> GetRequestAsync(string url)
        {
            HttpResponseMessage response = await Client.GetAsync(url);
            response.EnsureSuccessStatusCode();
            string responseBody = await response.Content.ReadAsStringAsync();
            return responseBody;
        }

        static async Task<string> PostRequestAsync(string url, string requestBody)
        {
            HttpContent content = new StringContent(requestBody);
            HttpResponseMessage response = await Client.PostAsync(url, content);
            response.EnsureSuccessStatusCode();
            string responseBody = await response.Content.ReadAsStringAsync();
            return responseBody;
        }
    }
}
